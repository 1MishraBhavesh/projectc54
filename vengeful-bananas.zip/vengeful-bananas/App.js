import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class SOUND1 extends Component {
  displayAlert = () => {
    alert('I am a alert box');
  };
  render() {
    return (
      <View>
      
      <Button title="SOUND1" color={this.props.color} onPress={()=>Alert.alert('PlaySound1')} />
      </View>
    );
  }
}

class SOUND2 extends Component {
  displayAlert = () => {
    alert('I am a alert box');
  };
  render() {
    return (
      <View>
      
      <Button title="SOUND2" color={this.props.color} onPress={()=>Alert.alert('PlaySound2')} />
      </View>
    );
  }
}class SOUND3 extends Component {
  displayAlert = () => {
    alert('I am a alert box');
  };
  render() {
    return (
      <View>
      
      <Button title="SOUND3" color={this.props.color} onPress={()=>Alert.alert('PlaySound3')} />
      </View>
    );
  }
}class SOUND4 extends Component {
  displayAlert = () => {
    alert('I am a alert box');
  };
  render() {
    return (
      <View>
      
      <Button title="SOUND4" color={this.props.color} onPress={()=>Alert.alert('PlaySound4')} />
      </View>
    );
  }
}class SOUND5 extends Component {
  displayAlert = () => {
    alert('I am a alert box');
  };
  render() {
    return (
      <View>
      
      <Button title="SOUND5" color={this.props.color} onPress={()=>Alert.alert('PlaySound5')} />
      </View>
    );
  }
}
export default class App extends Component {
  render() {
    return (
      <View style={{ marginTop: 100 }}>
        <SOUND1 color="red"  />
       <SOUND2 color="blue"  />
       <SOUND3 color="lightgreen"  />
       <SOUND4 color="yellow"  />
       <SOUND5 color="pink"  />
        
      </View>
    );
  }
}
